﻿using CrudExample.Domain;
using GenericCRUD.Application;
using GenericCRUD.Domain;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Web.Http;

namespace CrudExample.Controllers
{
    public class CrudController : ApiController
    {
        private CrudService service;

        public CrudController()
        {
            this.service = new CrudService();
        }

        [HttpPost]
        public ListResponse List([FromBody]List<FilterCondition> filters, [FromUri]string entity, [FromUri]int startIndex = 0, [FromUri]int pageSize = 10, [FromUri]string sorting = "")
        {
            var response = this.service.GetItems(entity, startIndex, pageSize, sorting, filters);
            return response;
        }

        [HttpPost]
        public ListResponse Options(string entity)
        {
            return this.service.GetOptions(entity);
        }

        [HttpGet]
        public GetByIdResponse GetById([FromUri]string entity, [FromUri]Guid Id)
        {
            return this.service.GetById(entity, Id);
        }

        [HttpPost]
        public CreateResponse Create([FromUri]string entity, JObject obj)
        {
            return this.service.Create(entity, EntityFactory.JObjectToEntity(entity, obj));
        }

        [HttpPost]
        public UpdateResponse Update([FromUri]string entity, JObject obj)
        {
            return this.service.Update(entity, EntityFactory.JObjectToEntity(entity, obj));
        }

        [HttpPost]
        public DeleteResponse Delete([FromUri]string entity, JObject obj)
        {
            return this.service.Delete(entity, ((Entity)EntityFactory.JObjectToEntity(entity, obj)).Id);
        }

        [HttpGet]
        public List<FilterOption> EntityFilterProperties(string entity)
        {
            return this.service.GetEntityFilterProperties(entity);
        }

    }
}
