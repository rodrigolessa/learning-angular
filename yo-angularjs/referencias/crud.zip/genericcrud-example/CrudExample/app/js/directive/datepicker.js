﻿angular.module('datepicker', []).directive('datepicker', function() {
    return {
        restrict: 'A',
        require : 'ngModel',
        link: function(scope, element, attrs, ngModelCtrl) {
            $(element).datepicker({
                dateFormat:'dd/mm/yyyy',
                language: 'pt-BR',
                pickTime: false,
            }).on('changeDate', function(e) {
                ngModelCtrl.$setViewValue(e.date.toLocaleDateString());
                scope.$apply();
            });
        }
    };
});