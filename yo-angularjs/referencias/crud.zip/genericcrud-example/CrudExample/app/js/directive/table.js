﻿angular.module('table', ['datepicker', 'ngMaterial']).directive('table', function ($http, $mdToast) {
    return {
        restrict: 'A',
        scope: {
            table: '=',
            filter: '='
        },
        template: '<div>' +
                    '<div class="generic-crud-table-header">' +
                        '<h2 class="generic-crud-table-title">{{table.title}}</h1>' +
                        '<div class="generic-crud-table-header-toolbar">' +
                            '<button class="generic-crud-table-toolbar-button" ng-click="addOptionToFilter()">Adicionar Filtro</button>' +
                            '<button class="generic-crud-table-toolbar-button" ng-click="showCreateForm()">Novo Registro</button>' +
                        '</div>' +
                    '</div>' +
                    '<div class="generic-crud-filter-wrapper" ng-show="optionsToFilter.length > 0">' +
                        '<div class="generic-crud-filter-row" ng-repeat="item in optionsToFilter">' +
                            '<input-container label="Campo" class="generic-crud-filter-field-name">' +
                                '<select ng-model="optionsToFilter[$index].Field" ng-options="option.Field for option in filterOptionsArray" ng-change="selectFirstOperator($index)"></select>' +
                            '</input-container>' +
                            '<input-container label="Operador" class="generic-crud-filter-field-operator">' +
                                '<select ng-model="optionsToFilter[$index].Operator" ng-options="operator.Name for operator in optionsToFilter[$index].Field.Operators"></select>' +
                            '</input-container>' +
                            '<input-container label="Valor" class="generic-crud-filter-field-value" ng-if="optionsToFilter[$index].Field.InputType == \'input\'">' +
                                '<input type="text" ng-model="optionsToFilter[$index].Value"/>' +
                            '</input-container>' +
                            '<input-container label="Valor" class="generic-crud-filter-field-value" ng-if="optionsToFilter[$index].Field.InputType == \'datepicker\'">' +
                                '<input type="text" ng-model="optionsToFilter[$index].Value" datepicker/>' +
                            '</input-container>' +
                            '<input-container label="Valor" class="generic-crud-filter-field-value" ng-if="optionsToFilter[$index].Field.InputType == \'select\'">' +
                                '<select ng-model="optionsToFilter[$index].Value" ng-options="option.Value as option.DisplayText for option in optionsToFilter[$index].Field.Items"></select>' +
                            '</input-container>' +
                            '<a class="generic-crud-filter-button" ng-click="addOptionToFilter()"><img src="app/img/plus.png"></a>' +
                            '<a class="generic-crud-filter-button" ng-click="removeOptionToFilter($index)"><img src="app/img/minus.png"></a>' +
                        '</div>' +
                        '<div class="generic-crud-filter-footer">' +
                            '<button class="generic-crud-table-toolbar-button" ng-click="cleanFilter()">Limpar Filtros</button>' +
                            '<button class="generic-crud-table-toolbar-button" ng-click="executeFilter()">Filtrar</button>' +
                        '</div>' +
                    '</div>' +
                '</div>',
        link: function (scope, element, attrs) {

            scope.filterOptionsArray = [];
            scope.optionsToFilter = [];

            scope.$watch('table', function (newValue) {

                if (typeof newValue.actions.filterAction == 'string') {
                    $http.get(newValue.actions.filterAction).success(function (data) {
                        scope.filterOptionsArray = data;
                    });
                }
                newValue.recordAdded = function () {
                    $mdToast.show(
                      $mdToast.simple()
                        .textContent('Registro adicionado com sucesso!')
                        .position('bottom left')
                        .hideDelay(3000)
                    );
                };
                newValue.recordUpdated = function () {
                    $mdToast.show(
                      $mdToast.simple()
                        .textContent('Registro atualizado com sucesso!')
                        .position('bottom left')
                        .hideDelay(3000)
                    );
                };
                newValue.recordDeleted = function () {
                    $mdToast.show(
                      $mdToast.simple()
                        .textContent('Registro removido com sucesso!')
                        .position('bottom left')
                        .hideDelay(3000)
                    );
                }
                element.jtable(newValue).jtable('load');
            });
            scope.$watch('filter', function (newValue) {
            });

            scope.addOptionToFilter = function ($index) {
                scope.optionsToFilter.push({ Field: scope.filterOptionsArray[0], Operator: scope.filterOptionsArray[0].Operators[0] });
            }

            scope.removeOptionToFilter = function (index) {
                scope.optionsToFilter.splice(index, 1);
                scope.executeFilter();
            }

            scope.executeFilter = function () {
                var tableFilterArray = [];
                for (var i = 0; i < scope.optionsToFilter.length; i++) {
                    tableFilterArray.push({
                        Field: scope.optionsToFilter[i].Field.Field,
                        Operator: scope.optionsToFilter[i].Operator.Value,
                        Value: scope.optionsToFilter[i].Value
                    });
                }
                element.jtable('load', JSON.stringify(tableFilterArray));
            }

            scope.showCreateForm = function () {
                element.jtable('showCreateForm');
            }

            scope.selectFirstOperator = function ($index) {
                scope.optionsToFilter[$index].Operator = scope.optionsToFilter[$index].Field.Operators[0];
            }
        }
    }

})