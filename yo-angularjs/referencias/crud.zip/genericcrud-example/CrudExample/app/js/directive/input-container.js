﻿angular.module('inputContainer', [])
.directive('inputContainer', function () {
    return {
        restrict: 'E',
        transclude: true,
        scope: {
            label: '@'
        },
        template: '<div>' +
                    '<span>{{label}}</span>' +
                    '<div ng-transclude></div>' +
                '</div>',
        link: function (scope, element, attrs) {
            var input = angular.element(element[0].querySelector("select, input"));
            input.on('focus', function () {
                element.addClass('label-min');
            });
            input.on('blur', function () {
                if (!angular.element(this).val().trim()) {
                    element.removeClass('label-min');
                }
            });

        }
    }
});