﻿var crud = angular.module('crud', ['ngRoute', 'ngAnimate', 'ngMaterial', 'inputContainer', 'table', 'datepicker']);
crud.config(function ($routeProvider) {
    $routeProvider.when('/crud/:entity', {
        templateUrl: '/Home/Cadastro',
        controller: 'exampleCtrl'
    });
});

var app = {
    views: {}
};