﻿app.views.CategoriaProduto = {
    options: {
        title: 'Categorias de Produto',
        paging: true,
        pageSize: 10,
        sorting: true,
        defaultSorting: 'Nome ASC',
        actions: {
            listAction: '/api/crud/list?entity=CategoriaProduto',
            createAction: '/api/crud/create?entity=CategoriaProduto',
            deleteAction: '/api/crud/delete?entity=CategoriaProduto',
            updateAction: '/api/crud/update?entity=CategoriaProduto',
            filterAction: '/api/crud/EntityFilterProperties?entity=CategoriaProduto'
        },
        fields: {
            Id: {
                key: true,
                list: false
            },
            Nome: {
                title: 'Nome',
                width: '40%'
            }
        }
    }
};

