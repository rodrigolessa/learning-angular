﻿app.views.ProcessoMarca = {
    options: {
        title: 'Processos de Marca',
        paging: true,
        pageSize: 10,
        sorting: true,
        defaultSorting: 'Numero ASC',
        actions: {
            listAction: '/api/crud/list?entity=ProcessoMarca',
            createAction: '/api/crud/create?entity=ProcessoMarca',
            deleteAction: '/api/crud/delete?entity=ProcessoMarca',
            updateAction: '/api/crud/update?entity=ProcessoMarca',
            filterAction: '/api/crud/EntityFilterProperties?entity=ProcessoMarca'
        },
        fields: {
            Id: {
                key: true,
                list: false
            },
            Numero: {
                title: 'Processo',
            },
            InicioVigencia: {
                title: 'Início da Vigência',
                type: 'date',
                displayFormat: 'dd/mm/yy'
            },
            DataDeposito: {
                title: 'Data de Depósito',
                type: 'date',
                displayFormat: 'dd/mm/yy'
            },
            DataProrrogacao: {
                title: 'Data de Prorrogação',
                type: 'date',
                displayFormat: 'dd/mm/yy'
            },
            DataConcessao: {
                title: 'Data de Concessão',
                type: 'date',
                displayFormat: 'dd/mm/yy'
            }
        }
    }
};

