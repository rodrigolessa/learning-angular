﻿app.views.Produto = {
    options: {
        title: 'Produtos',
        paging: true,
        pageSize: 10,
        sorting: true,
        defaultSorting: 'Nome ASC',
        actions: {
            listAction: '/api/crud/list?entity=Produto',
            createAction: '/api/crud/create?entity=Produto',
            deleteAction: '/api/crud/delete?entity=Produto',
            updateAction: '/api/crud/update?entity=Produto',
            filterAction: '/api/crud/EntityFilterProperties?entity=Produto'
        },
        fields: {
            Id: {
                key: true,
                list: false
            },
            Nome: {
                title: 'Nome',
                width: '40%'
            },
            Valor: {
                title: 'Valor'
            },
            Quantidade: {
                title: 'Quantidade'
            },
            CategoriaProdutoId: {
                title: 'Categoria',
                options: '/api/crud/options?entity=CategoriaProduto',
            }
        }
    }
};

