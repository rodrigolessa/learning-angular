﻿app.views.Dependente = {
    options: {
        title: 'Dependentes',
        paging: true,
        pageSize: 10,
        sorting: true,
        defaultSorting: 'Nome ASC',
        actions: {
            listAction: '/api/crud/list?entity=Dependente',
            createAction: '/api/crud/create?entity=Dependente',
            deleteAction: '/api/crud/delete?entity=Dependente',
            updateAction: '/api/crud/update?entity=Dependente',
            filterAction: '/api/crud/EntityFilterProperties?entity=Dependente'
        },
        fields: {
            Id: {
                key: true,
                list: false
            },
            Nome: {
                title: 'Nome',
                width: '40%'
            },

            Email: {
                title: 'Email',
                width: '40%'
            },

            Senha: {
                title: 'Senha',
                width: '40%',
                list: false,
                type: 'password'
            }
        }
    }
};

