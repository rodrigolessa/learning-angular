﻿app.views.Usuario = {
    options: {
        title: 'Usuários',
        paging: true,
        pageSize: 10,
        sorting: true,
        defaultSorting: 'Nome ASC',
        actions: {
            listAction: '/api/crud/list?entity=Usuario',
            createAction: '/api/crud/create?entity=Usuario',
            deleteAction: '/api/crud/delete?entity=Usuario',
            updateAction: '/api/crud/update?entity=Usuario',
            filterAction: '/api/crud/EntityFilterProperties?entity=Usuario'
        },
        fields: {
            Id: {
                key: true,
                list: false
            },
            Nome: {
                title: 'Nome',
                width: '40%'
            }
        }
    }
};

