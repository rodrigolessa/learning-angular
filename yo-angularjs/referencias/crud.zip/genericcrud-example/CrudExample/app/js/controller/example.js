﻿crud.controller('exampleCtrl', function ($scope, $routeParams) {
    var options = app.views[$routeParams.entity].options;
    $scope.options = options;
});