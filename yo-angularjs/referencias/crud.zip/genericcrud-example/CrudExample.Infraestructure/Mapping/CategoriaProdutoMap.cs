﻿using CrudExample.Domain;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace CrudExample.Infraestructure.Mapping
{
    public class CategoriaProdutoMap : EntityTypeConfiguration<CategoriaProduto>
    {
        public CategoriaProdutoMap()
        {
            HasKey(t => t.Id);
            Property(t => t.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(t => t.Nome).IsRequired();
            ToTable("CategoriaProduto");
        }
    }
}
