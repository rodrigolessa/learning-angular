﻿using CrudExample.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrudExample.Infraestructure.Mapping
{
    public class ProcessoMarcaMap : EntityTypeConfiguration<ProcessoMarca>
    {
        public ProcessoMarcaMap()
        {
            HasKey(t => t.Id);
            Property(t => t.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(t => t.Numero).IsRequired();
            Property(t => t.InicioVigencia).IsRequired();
            Property(t => t.DataDeposito).IsRequired();
            Property(t => t.DataProrrogacao).IsRequired();
            Property(t => t.DataConcessao).IsRequired();
            ToTable("ProcessosMarcas");
        }
    }
}
