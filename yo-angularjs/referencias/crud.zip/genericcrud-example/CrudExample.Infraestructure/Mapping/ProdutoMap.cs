﻿using CrudExample.Domain;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace CrudExample.Infraestructure.Mapping
{
    public class ProdutoMap : EntityTypeConfiguration<Produto>
    {
        public ProdutoMap()
        {
            HasKey(t => t.Id);
            Property(t => t.Id).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(t => t.Nome).IsRequired();
            Property(t => t.Valor).IsRequired();
            Property(t => t.Quantidade).IsRequired();
            Property(t => t.CategoriaProdutoId).IsRequired();
            HasRequired<CategoriaProduto>(e => e.Categoria).WithMany(e => e.Produtos);
            ToTable("Produtos");
        }
    }
}
