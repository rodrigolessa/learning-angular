namespace CrudExample.Infraestructure.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CategoriaobrigatóriaemProduto : DbMigration
    {
        public override void Up()
        {
            DropForeignKey("dbo.Produtos", "CategoriaProdutoId", "dbo.CategoriaProduto");
            DropIndex("dbo.Produtos", new[] { "CategoriaProdutoId" });
            AlterColumn("dbo.Produtos", "CategoriaProdutoId", c => c.Guid(nullable: false));
            CreateIndex("dbo.Produtos", "CategoriaProdutoId");
            AddForeignKey("dbo.Produtos", "CategoriaProdutoId", "dbo.CategoriaProduto", "Id", cascadeDelete: true);
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Produtos", "CategoriaProdutoId", "dbo.CategoriaProduto");
            DropIndex("dbo.Produtos", new[] { "CategoriaProdutoId" });
            AlterColumn("dbo.Produtos", "CategoriaProdutoId", c => c.Guid());
            CreateIndex("dbo.Produtos", "CategoriaProdutoId");
            AddForeignKey("dbo.Produtos", "CategoriaProdutoId", "dbo.CategoriaProduto", "Id");
        }
    }
}
