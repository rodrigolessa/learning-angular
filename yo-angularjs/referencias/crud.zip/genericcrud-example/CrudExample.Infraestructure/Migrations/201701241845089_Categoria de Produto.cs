namespace CrudExample.Infraestructure.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class CategoriadeProduto : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.CategoriaProduto",
                c => new
                    {
                        Id = c.Guid(nullable: false, identity: true),
                        Nome = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            AddColumn("dbo.Produtos", "CategoriaProdutoId", c => c.Guid());
            CreateIndex("dbo.Produtos", "CategoriaProdutoId");
            AddForeignKey("dbo.Produtos", "CategoriaProdutoId", "dbo.CategoriaProduto", "Id");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Produtos", "CategoriaProdutoId", "dbo.CategoriaProduto");
            DropIndex("dbo.Produtos", new[] { "CategoriaProdutoId" });
            DropColumn("dbo.Produtos", "CategoriaProdutoId");
            DropTable("dbo.CategoriaProduto");
        }
    }
}
