namespace CrudExample.Infraestructure.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class TabelaProcessosMarcas : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.ProcessosMarcas",
                c => new
                    {
                        Id = c.Guid(nullable: false, identity: true),
                        Numero = c.String(nullable: false),
                        InicioVigencia = c.DateTime(nullable: false),
                        DataDeposito = c.DateTime(nullable: false),
                        DataProrrogacao = c.DateTime(nullable: false),
                        DataConcessao = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.ProcessosMarcas");
        }
    }
}
