﻿using GenericCRUD.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrudExample.Domain
{
    public class CategoriaProduto: Entity
    {
        [Filterable]
        [DisplayName("Nome")]
        public string Nome { get; set; }
        
        public virtual ICollection<Produto> Produtos { get; set; }
    }
}
