﻿using GenericCRUD.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrudExample.Domain
{
    public class ProcessoMarca: Entity
    {
        [Filterable]
        [DisplayName("Processo")]
        public string Numero { get; set; }
        [Filterable]
        [DisplayName("Início da Vigência")]
        public DateTime InicioVigencia { get; set; }
        [Filterable]
        [DisplayName("Data de Depósito")]
        public DateTime DataDeposito { get; set; }
        [Filterable]
        [DisplayName("Data de Prorrogação")]
        public DateTime DataProrrogacao { get; set; }
        [Filterable]
        [DisplayName("Data de Concessão")]
        public DateTime DataConcessao { get; set; }
    }
}
