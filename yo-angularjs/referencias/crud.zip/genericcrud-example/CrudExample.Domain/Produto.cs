﻿using GenericCRUD.Domain;
using System;
using System.ComponentModel;

namespace CrudExample.Domain
{
    public class Produto: Entity
    {
        [Filterable]
        [DisplayName("Nome")]
        public string Nome { get; set; }
        [Filterable]
        [DisplayName("Valor")]
        public decimal Valor { get; set; }
        [Filterable]
        [DisplayName("Quantidade")]
        public int Quantidade { get; set; }
        [Filterable]
        [DisplayName("Categoria")]
        public Guid CategoriaProdutoId { get; set; }

        public virtual CategoriaProduto Categoria { get; set; }
    }
}
