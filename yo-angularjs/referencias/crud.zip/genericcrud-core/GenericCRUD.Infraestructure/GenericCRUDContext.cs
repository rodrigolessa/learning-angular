﻿using GenericCRUD.Domain;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace GenericCRUD.Infraestructure
{
    public class GenericCRUDContext : DbContext
    {

        public GenericCRUDContext(string connectionString)
            : base(connectionString)
        {

        }

        public new IDbSet<TEntity> Set<TEntity>() where TEntity : Entity
        {
            return base.Set<TEntity>();
        }

        protected void CreateMap(DbModelBuilder modelBuilder)
        {
            var typesToRegister = GetMappingTypes().Where(type => !String.IsNullOrEmpty(type.Namespace)).Where(type => type.BaseType != null && type.BaseType.IsGenericType && type.BaseType.GetGenericTypeDefinition() == typeof(EntityTypeConfiguration<>));
            foreach (var type in typesToRegister)
            {
                dynamic configurationInstance = Activator.CreateInstance(type);
                modelBuilder.Configurations.Add(configurationInstance);
            }
        }

        private Type[] GetMappingTypes()
        {
            var path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
            path = path.Substring(6);
            var a = Assembly.LoadFrom(path + @"\" + ConfigurationManager.AppSettings["genericcrud:DbContextNamespace"] + ".dll");
            var typesToRegister = a.GetTypes();
            return typesToRegister;
        }
    }
}
