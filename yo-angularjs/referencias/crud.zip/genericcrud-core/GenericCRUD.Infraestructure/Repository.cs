﻿using GenericCRUD.Domain;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Dynamic;
using System.Data.Entity.Core;
using System.Collections;
using System.Diagnostics;

namespace GenericCRUD.Infraestructure
{
    public class Repository<T>
        where T : Entity
    {

        private readonly DbContext context;
        private IDbSet<T> entities;
        string errorMessage = string.Empty;
        private IDbSet<T> Entities
        {
            get
            {
                if (entities == null)
                {
                    entities = context.Set<T>();
                }
                return entities;
            }
        }

        public Repository(DbContext context)
        {
            this.context = context;
        }

        public T GetById(Guid id)
        {
            return this.Entities.Find(id);
        }

        public ListResponse List(ListRequest request)
        {
            ListResponse response = new ListResponse();
            var entities = (IQueryable<T>)this.Entities;
            IOrderedQueryable<T> orderedList;
            IEnumerable<T> filteredList;
            IQueryable<T> filteredEntities = ExecuteFilters(request.Filters, request.IgnoreLogicalDelete);
            if (string.IsNullOrEmpty(request.Sorting))
                orderedList = filteredEntities.OrderBy(e => e.Id);
            else
                orderedList = filteredEntities.OrderBy(request.Sorting);
            response.Count = orderedList.Count();
            filteredList = orderedList.Skip(request.StartIndex);
            filteredList = filteredList.Take(request.PageSize);
            response.Items = filteredList.ToList();
            response.PageSize = request.PageSize;
            return response;
        }
        
        public ListResponse ListOptions()
        {
            ListResponse response = new ListResponse();
            var entities = this.Entities.AsEnumerable().Select("new(Id as Value, Nome as DisplayText)").OrderBy("DisplayText ASC").Cast<DynamicClass>().ToList();
            List<Option> result = new List<Option>();
            foreach (dynamic d in entities)
            {
                result.Add(new Option { Value = d.Value, DisplayText = d.DisplayText });
            }
            response.Items = result;
            return response;
        }

        public T Insert(T entity)
        {
            try
            {
                if (entity == null)
                {
                    throw new ArgumentNullException("entity");
                }
                entity.Active = true;
                this.Entities.Add(entity);
                this.context.SaveChanges();
                return entity;
            }
            catch (DbEntityValidationException dbEx)
            {

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage) + Environment.NewLine;
                    }
                }
                throw new Exception(errorMessage, dbEx);
            }
        }

        public void Update(T entity)
        {
            try
            {
                if (entity == null)
                {
                    throw new ArgumentNullException("entity");
                }
                var local = this.context.Set<T>().Local.FirstOrDefault(e => e.Id == entity.Id);
                if (local != null)
                {
                    this.context.Entry(local).State = EntityState.Detached;
                }
                this.context.Entry(entity).State = EntityState.Modified;
                this.context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += Environment.NewLine + string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage);
                    }
                }

                throw new Exception(errorMessage, dbEx);
            }
        }

        public void LogicalDelete(T entity)
        {
            entity.Active = false;
            Update(entity);
        }

        public void PhysicalDelete(T entity)
        {
            try
            {
                if (entity == null)
                {
                    throw new ArgumentNullException("entity");
                }
                var local = this.context.Set<T>().Local.FirstOrDefault(e => e.Id == entity.Id);
                if (local != null)
                {
                    this.context.Entry(local).State = EntityState.Detached;
                }
                this.Entities.Attach(entity);
                this.Entities.Remove(entity);
                this.context.SaveChanges();
            }
            catch (DbEntityValidationException dbEx)
            {

                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        errorMessage += Environment.NewLine + string.Format("Property: {0} Error: {1}",
                        validationError.PropertyName, validationError.ErrorMessage);
                    }
                }
                throw new Exception(errorMessage, dbEx);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="filters"></param>
        /// <param name="ignoreLogicalDelete">Se for true a query irá listar as entidades que estão removidas logicamente</param>
        /// <returns></returns>
        private IQueryable<T> ExecuteFilters(List<FilterCondition> filters, bool ignoreLogicalDelete = false)
        {
            IQueryable<T> result = null;
            if (filters.Count == 0)
                return this.Entities;
            var query = "";
            for (int i = 0; i < filters.Count; i++)
            {
                FilterCondition filter = filters[i];
                switch (filter.Operator)
                {
                    case "contains":
                        query += string.Format("{0}.Contains(@{1})", filter.Field, i);
                        break;
                    default:
                        query += string.Format("{0} {1} @{2}", filter.Field, filter.Operator, i);
                        break;
                }
                query += " AND ";

            }
            if(!ignoreLogicalDelete)
            {
                query += "Active = true AND ";
            }
            query = query.Substring(0, query.Length - 5);
            result = this.Entities.Where(query, filters.Select(f => f.Value).ToArray());
            return result;
        }

    }


    public static class EnumerableExtension
    {

        public static IOrderedQueryable<TSource> OrderBy<TSource>(this IEnumerable<TSource> query, string propertyName)
        {
            var entityType = typeof(TSource);
            var propertyInfo = entityType.GetProperty(propertyName.Split(' ')[0]);
            ParameterExpression arg = Expression.Parameter(entityType, "x");
            MemberExpression property = Expression.Property(arg, propertyName.Split(' ')[0]);
            var selector = Expression.Lambda(property, new ParameterExpression[] { arg });
            var enumarableType = typeof(System.Linq.Queryable);
            var method = enumarableType.GetMethods()
                .Where(m => m.Name == (propertyName.Split(' ')[1] == "ASC" ? "OrderBy" : "OrderByDescending") && m.IsGenericMethodDefinition)
                 .Where(m =>
                 {
                     var parameters = m.GetParameters().ToList();
                     return parameters.Count == 2;
                 }).Single();
            MethodInfo genericMethod = method
                 .MakeGenericMethod(entityType, propertyInfo.PropertyType);
            var newQuery = (IOrderedQueryable<TSource>)genericMethod
                 .Invoke(genericMethod, new object[] { query, selector });
            return newQuery;
        }

    }
}
