﻿using Newtonsoft.Json.Linq;
using NLog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace GenericCRUD.Application
{
    public class EntityFactory
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public static object JObjectToEntity(string entityName, JObject obj)
        {
            Type entityType = EntityTypes.Entities[entityName].EntityType;
            return obj.ToObject(entityType);
        }

        
    }
}
