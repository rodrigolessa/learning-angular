﻿using GenericCRUD.Domain;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.IO;
using System.Reflection;

namespace GenericCRUD.Application
{
    public class GenericCrudConfig
    {
        public static void Register()
        {
            RegisterEntityTypes();
            RegisterDbContextType();
            RegisterDeleteType();
        }

        private static void RegisterEntityTypes()
        {
            var path = Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
            path = path.Substring(6);
            var a = Assembly.LoadFrom(path + @"\" + ConfigurationManager.AppSettings["genericcrud:EntitiesNamespace"] + ".dll");
            var types = a.GetTypes();
            foreach (var type in types)
            {
                var properties = type.GetProperties();
                List<PropertyMetadata> propsMetadata = new List<PropertyMetadata>();
                foreach (var prop in properties)
                {
                    var key = "";
                    var displayName = prop.GetCustomAttribute(typeof(DisplayNameAttribute)) as DisplayNameAttribute;
                    if (displayName != null)
                        key = displayName.DisplayName;
                    propsMetadata.Add(new PropertyMetadata() { 
                        Type = prop.PropertyType,
                        Name = prop.Name,
                        DisplayName = key
                    });
                }

                var entityMetadata = new EntityMetadata()
                {
                    EntityName = type.Name,
                    EntityType = type,
                    Properties = propsMetadata
                };
                EntityTypes.Entities.Add(type.Name, entityMetadata);
            }
        }

        private static void RegisterDbContextType()
        {
        }

        private static void RegisterDeleteType()
        {
            var deleteType = ConfigurationManager.AppSettings["genericcrud:DeleteType"];
            DeleteMethod.Type = deleteType == "Logical" ? DeleteType.Logical : DeleteType.Physical; 
        }
    }
}
