﻿using GenericCRUD.Domain;
using GenericCRUD.Infraestructure;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Dynamic;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Collections;
using System.Configuration;
using NLog;

namespace GenericCRUD.Application
{
    public class CrudService
    {

        private object context;
        private static Logger logger = LogManager.GetCurrentClassLogger();
        private static Dictionary<string, RepositoryMetaData> repositories;
        public static Dictionary<string, RepositoryMetaData> Repositories
        {
            get
            {
                if (repositories == null)
                {
                    repositories = new Dictionary<string, RepositoryMetaData>();
                }
                return repositories;
            }
        }

        public CrudService()
        {
            context = Activator.CreateInstance(GetDbContextType());
        }

        public ListResponse GetItems(string entityName, int startIndex, int pageSize, string sorting, List<FilterCondition> filters, bool ignoreLogicalDelete = false)
        {
            try
            {
                filters = PrepareFilters(entityName, filters);
                ListResponse response = ExecuteList(entityName, startIndex, pageSize, sorting, ignoreLogicalDelete, filters);
                return response;
            }
            catch (TargetInvocationException e)
            {
                throw e.InnerException;
            }
        }

        public ListResponse GetOptions(string entityName)
        {
            try
            {
                var repositoryMetaData = GetRepository(entityName);
                ListResponse response = new ListResponse();
                ListResponse result = (ListResponse)repositoryMetaData.OptionsMethod.Invoke(repositoryMetaData.Repository, new object[] { });
                response.Items = result.Items;
                return response;
            }
            catch (TargetInvocationException e)
            {
                throw e.InnerException;
            }
        }

        public GetByIdResponse GetById(string entityName, Guid id)
        {
            try
            {
                var repositoryMetaData = GetRepository(entityName);
                GetByIdResponse response = new GetByIdResponse();
                var result = (Entity)repositoryMetaData.GetByIdMethod.Invoke(repositoryMetaData.Repository, new object[] { id });
                response.Entity = result;

                return response;
            }
            catch (TargetInvocationException e)
            {
                throw e.InnerException;
            }
        }

        public CreateResponse Create(string entityName, object entity)
        {
            try
            {
                
                var repositoryMetaData = GetRepository(entityName);
                CreateResponse response = new CreateResponse();
                ValidateEntity(entity, response);
                if (response.Success) //isValid
                {
                    var result = repositoryMetaData.CreateMethod.Invoke(repositoryMetaData.Repository, new object[] { entity });
                    response.Entity = (Entity)result;
                }
                return response;
            }
            catch (TargetInvocationException e)
            {
                throw e.InnerException;
            }
        }

        public UpdateResponse Update(string entityName, object entity)
        {
            try
            {
                var repositoryMetaData = GetRepository(entityName);
                UpdateResponse response = new UpdateResponse();
                ValidateEntity(entity, response);
                if (response.Success) //isValid
                {
                    repositoryMetaData.UpdateMethod.Invoke(repositoryMetaData.Repository, new object[] { entity });
                }
                return response;
            }
            catch (TargetInvocationException e)
            {
                throw e.InnerException;
            }
        }

        public DeleteResponse LogicalDelete(string entityName, Guid id)
        {
            try
            {
                var repositoryMetaData = GetRepository(entityName);
                var entityType = EntityTypes.Entities[entityName].EntityType;
                var entity = Activator.CreateInstance(entityType);
                PropertyInfo[] properties = entityType.GetProperties();
                foreach (var property in properties)
                {
                    if (property.Name == "Id")
                    {
                        property.SetValue(entity, id);
                        break;
                    }
                }
                DeleteResponse response = new DeleteResponse();
                repositoryMetaData.LogicalDeleteMethod.Invoke(repositoryMetaData.Repository, new object[] { entity });
                return response;
            }
            catch (TargetInvocationException e)
            {
                throw e.InnerException;
            }
        }

        public DeleteResponse PhysicalDelete(string entityName, Guid id)
        {
            try
            {
                var repositoryMetaData = GetRepository(entityName);
                var entityType = EntityTypes.Entities[entityName].EntityType;
                var entity = Activator.CreateInstance(entityType);
                PropertyInfo[] properties = entityType.GetProperties();
                foreach (var property in properties)
                {
                    if (property.Name == "Id")
                    {
                        property.SetValue(entity, id);
                        break;
                    }
                }
                DeleteResponse response = new DeleteResponse();
                repositoryMetaData.PhysicalDeleteMethod.Invoke(repositoryMetaData.Repository, new object[] { entity });
                return response;
            }
            catch (TargetInvocationException e)
            {
                throw e.InnerException;
            }
        }

        public DeleteResponse Delete(string entityName, Guid id)
        {
            try
            {
                if (DeleteMethod.Type == DeleteType.Logical)
                    return LogicalDelete(entityName, id);
                else
                    return PhysicalDelete(entityName, id);
            }
            catch (TargetInvocationException e)
            {
                throw e.InnerException;
            }
        }

        public List<FilterOption> GetEntityFilterProperties(string entityName)
        {
            var filterProperties = EntityTypes.Entities[entityName].EntityType.GetProperties().Where(p => p.GetCustomAttributes(typeof(FilterableAttribute)).Count() == 1);
            List<FilterOption> filterOptions = new List<FilterOption>();
            foreach (var prop in filterProperties)
            {
                DisplayNameAttribute d = (DisplayNameAttribute)prop.GetCustomAttribute(typeof(DisplayNameAttribute));
                filterOptions.Add(GetFilterOptionByType(prop.Name, d.DisplayName, prop.PropertyType));
            }
            return filterOptions;
        }

        private void ValidateEntity(object entity, Response response)
        {
            var validationContext = new ValidationContext(entity, null, null);
            var results = new List<ValidationResult>();
            Validator.TryValidateObject(entity, validationContext, results, true);
            foreach (var item in results)
            {
                response.Errors.Add(item.ErrorMessage);
            }
        }

        private Type GetDbContextType()
        {
            var path = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
            path = path.Substring(6);
            var a = Assembly.LoadFrom(path + @"\" + ConfigurationManager.AppSettings["genericcrud:DbContextNamespace"] + ".dll");
            var types = a.GetTypes();
            var type = types.Where(t => t.Name == ConfigurationManager.AppSettings["genericcrud:DbContextName"]).FirstOrDefault();
            return type;
        }

        private FilterOption GetFilterOptionByType(string property, string field, Type type)
        {
            FilterOption option = new FilterOption();
            option.Field = field;
            List<FilterOperator> operators = new List<FilterOperator>();
            if (type == typeof(string))
            {
                option.InputType = "input";
                operators.Add(new FilterOperator() { Name = "Igual", Value = "=" });
                operators.Add(new FilterOperator() { Name = "Contém", Value = "contains" });
            }
            else if (type == typeof(int) || type == typeof(double) || type == typeof(float) || type == typeof(decimal))
            {
                option.InputType = "input";
                operators.Add(new FilterOperator() { Name = "Igual", Value = "=" });
                operators.Add(new FilterOperator() { Name = "Maior", Value = ">" });
                operators.Add(new FilterOperator() { Name = "Menor", Value = "<" });
                operators.Add(new FilterOperator() { Name = "Maior igual à", Value = ">=" });
                operators.Add(new FilterOperator() { Name = "Menor igual à", Value = "<=" });
            }
            else if(type == typeof(DateTime))
            {
                option.InputType = "datepicker";
                operators.Add(new FilterOperator() { Name = "Igual", Value = "=" });
                operators.Add(new FilterOperator() { Name = "Maior", Value = ">" });
                operators.Add(new FilterOperator() { Name = "Menor", Value = "<" });
                operators.Add(new FilterOperator() { Name = "Maior igual à", Value = ">=" });
                operators.Add(new FilterOperator() { Name = "Menor igual à", Value = "<=" });
            }
            else
            {
                if (property.Substring(property.Length - 2, 2) == "Id")
                {
                    var className = property.Substring(0, property.Length - 2);
                    option.InputType = "select";
                    operators.Add(new FilterOperator() { Name = "Igual", Value = "=" });
                    var optionsResponse = this.GetOptions(className);
                    option.Items = optionsResponse.Items;
                }
            }
            option.Operators = operators;
            return option;
        }

        private RepositoryMetaData GetRepository(string entityName)
        {
            RepositoryMetaData repositoryMetaData = null;
            Repositories.TryGetValue(entityName, out repositoryMetaData);
            if (repositoryMetaData == null)
            {
                var entityType = EntityTypes.Entities[entityName].EntityType;
                var repositoryType = typeof(Repository<>).MakeGenericType(entityType);
                var repository = Activator.CreateInstance(repositoryType, new object[] { context });
                repositoryMetaData = new RepositoryMetaData
                {
                    Repository = repository,
                    RepositoryType = repositoryType,
                    ListMethod = repositoryType.GetMethod("List"),
                    CreateMethod = repositoryType.GetMethod("Insert"),
                    UpdateMethod = repositoryType.GetMethod("Update"),
                    PhysicalDeleteMethod = repositoryType.GetMethod("PhysicalDelete"),
                    LogicalDeleteMethod = repositoryType.GetMethod("LogicalDelete"),
                    GetByIdMethod = repositoryType.GetMethod("GetById"),
                    OptionsMethod = repositoryType.GetMethod("ListOptions")
                };
                Repositories.Add(entityName, repositoryMetaData);
            }
            return repositoryMetaData;
        }

        private List<FilterCondition> PrepareFilters(string entityName, List<FilterCondition> filters)
        {
            if (filters == null)
                filters = new List<FilterCondition>();
            foreach (FilterCondition filter in filters)
            {
                filter.Field = EntityTypes.Entities[entityName].Properties.FirstOrDefault(p => p.DisplayName == filter.Field).Name;
                filter.Value = TypeDescriptor.GetConverter(EntityTypes.Entities[entityName].Properties.FirstOrDefault(p => p.Name == filter.Field).Type).ConvertFromInvariantString((string)filter.Value);
            }
            return filters;
        }

        private ListResponse ExecuteList(string entityName, int startIndex, int pageSize, string sorting, bool ignoreLogicalDelete, List<FilterCondition> filters)
        {
            var repositoryMetaData = GetRepository(entityName);
            ListRequest request = new ListRequest()
            {
                StartIndex = startIndex,
                PageSize = pageSize,
                Sorting = sorting,
                Filters = filters,
                IgnoreLogicalDelete = ignoreLogicalDelete
            };
            return (ListResponse)repositoryMetaData.ListMethod.Invoke(repositoryMetaData.Repository, new object[] { request });
        }
    }

}
