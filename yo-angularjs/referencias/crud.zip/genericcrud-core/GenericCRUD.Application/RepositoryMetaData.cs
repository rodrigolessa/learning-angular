﻿using GenericCRUD.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace GenericCRUD.Application
{
    public class RepositoryMetaData
    {
        public object Repository { get; set; }
        public Type RepositoryType { get; set; }
        public MethodInfo ListMethod { get; set; }
        public MethodInfo OptionsMethod { get; set; }
        public MethodInfo CreateMethod { get; set; }
        public MethodInfo UpdateMethod { get; set; }
        public MethodInfo DeleteMethod { get; set; }
        public MethodInfo PhysicalDeleteMethod { get; set; }
        public MethodInfo LogicalDeleteMethod { get; set; }
        public MethodInfo GetByIdMethod { get; set; }
    }
}
