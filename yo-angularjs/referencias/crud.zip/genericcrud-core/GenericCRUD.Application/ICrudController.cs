﻿using GenericCRUD.Domain;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCRUD.Application
{
    public interface ICrudController
    {
        ListResponse List(List<FilterCondition> filters, string entityName, int startIndex = 0, int pageSize = 10, string sorting = "");
        GetByIdResponse GetById(string entityName, Guid Id);
        CreateResponse Create(string entityName, JObject entity);
        UpdateResponse Update(string entityName, JObject entity);
        DeleteResponse Delete(string entityName, JObject entity);
    }
}
