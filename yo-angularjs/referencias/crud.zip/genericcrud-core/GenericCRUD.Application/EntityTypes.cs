﻿using GenericCRUD.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCRUD.Application
{
    public class EntityTypes
    {
        private static Dictionary<string, EntityMetadata> types;

        private EntityTypes() { }

        public static Dictionary<string, EntityMetadata> Entities
        {
            get
            {
                if (types == null)
                {
                    types = new Dictionary<string, EntityMetadata>();
                }
                return types;
            }
        }
    }
}
