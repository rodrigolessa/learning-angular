﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCRUD.Domain
{
    public enum DeleteType
    {
        Logical, Physical
    }


    public class DeleteMethod
    {
        private static DeleteType type;

        private DeleteMethod() { }

        public static DeleteType Type
        {
            get
            {
                if (type == null)
                {
                    type = DeleteType.Physical;
                }
                return type;
            }
            set
            {
                type = value;
            }
        }
    }
}
