﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCRUD.Domain
{
    public class FilterOption
    {
        public string Field { get; set; }
        public List<FilterOperator> Operators { get; set; }
        public string InputType { get; set; }

        public System.Collections.IList Items { get; set; }
    }
}
