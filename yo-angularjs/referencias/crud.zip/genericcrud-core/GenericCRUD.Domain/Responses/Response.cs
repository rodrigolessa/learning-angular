﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCRUD.Domain
{
    public class Response
    {
        public List<string> Errors { get; set; }
        public bool Success { get {
            return this.Errors.Count == 0;
            } 
        }


        public Response()
        {
            this.Errors = new List<string>();
        }
    }
}
