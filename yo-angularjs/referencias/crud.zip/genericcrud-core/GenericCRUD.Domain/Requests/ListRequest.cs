﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericCRUD.Domain
{
    public class ListRequest
    {
        public int PageSize { get; set; }
        public string Sorting { get; set; }
        public int Page { get; set; }

        public List<FilterCondition> Filters { get; set; }

        public int StartIndex { get; set; }

        public bool IgnoreLogicalDelete { get; set; }
    }
}
